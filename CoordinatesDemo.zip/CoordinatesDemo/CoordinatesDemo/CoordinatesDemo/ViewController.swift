//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Divya on 2/29/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Identify the minimum of X & Y values of the imageView
        let minX = imageViewOL.frame.minX
        let minY = imageViewOL.frame.minY
        
        print(minX, ",", minY)
        
        //Identify the mid of X & Y values of the imageView
        let midX = imageViewOL.frame.midX
        let midY = imageViewOL.frame.midY
        
        print(midX, ",", midY)
        
        //Identify the maximum of X & Y values of the imageView
        let maxX = imageViewOL.frame.maxX
        let maxY = imageViewOL.frame.maxY
        
        print(maxX, ",", maxY)
        
        //Move the imageView to the upper left corner of the View
        imageViewOL.frame.origin.x = 0
        imageViewOL.frame.origin.y = 0

        //Move the imageView to the upper right corner of the View
        imageViewOL.frame.origin.x = 330
        imageViewOL.frame.origin.y = 0
        
        //Move the imageView to the lower left corner of the View
        imageViewOL.frame.origin.x = 0
        imageViewOL.frame.origin.y = 832
        
        //Move the imageView to the lower right corner of the View
        imageViewOL.frame.origin.x = 330
        imageViewOL.frame.origin.y = 832
        
        //Move the imageView to the center of the screen
        imageViewOL.frame.origin.x = 215
        imageViewOL.frame.origin.y = 466
        
        //Move the imageView to the center of the View
        imageViewOL.frame.origin.x = 165
        imageViewOL.frame.origin.y = 416
        
        UIView.animate(withDuration: 1, delay: 0.5, animations: {
            self.imageViewOL.alpha = 0
            self.imageViewOL.alpha = 1
            self.imageViewOL.image=UIImage(named: "anime.jpeg")})
        
    }


}

